# Hello World

This is an example project


## Installation

```python
pip install hellocdk
```

## Usage

```python
from hellocdk import say_hello

# Generate "Hello, World!"
say_hello()

# Generate "Hello, Everybody!"
say_hello("Everybody")
```


